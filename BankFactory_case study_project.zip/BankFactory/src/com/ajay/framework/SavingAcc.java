package com.ajay.framework;

public abstract class SavingAcc extends BankAcc{
	
	protected boolean isSalary;
	static final private float MINBAL = 0; 
	
	
	public SavingAcc(int accNo, String accNm, float accBal, boolean isSalary) {
		super(accNo, accNm, accBal);
		this.isSalary = isSalary;
	}

	public void withdraw(float accBal)
	{
		System.out.println("accBal is:"+accBal);
	}

	@Override
	public String toString() {
		return "SavingAcc [isSalary=" + isSalary + ", accNo=" + accNo + ", accNm=" + accNm + ", accBal=" + accBal
				+ ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ "]";
	}

	public float getaccBal() {
		// TODO Auto-generated method stub
		return 0;
	}

}
