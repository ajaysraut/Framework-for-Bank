package com.ajay.framework;

public abstract class BankAcc {
	
	protected int accNo;
	protected String accNm;
	public float accBal;
	
	public BankAcc(int accNo, String accNm, float accBal) {
		super();
		this.accNo = accNo;
		this.accNm = accNm;
		this.accBal = accBal;
	}
	public void withdraw(float accBal)
	{
		System.out.println("account bal is withdraw and bal is:"+accBal);
	}
	public void deposite(float accBal)
	{
		System.out.println("Bal is deposite and accBal is:"+accBal);
	}
	@Override
	public String toString() {
		return "BankAcc [accNo=" + accNo + ", accNm=" + accNm + ", accBal=" + accBal + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
