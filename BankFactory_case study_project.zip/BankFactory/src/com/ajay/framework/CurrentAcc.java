package com.ajay.framework;

public abstract class CurrentAcc extends BankAcc{
	
	
	public CurrentAcc(int accNo, String accNm, float accBal, float creditLimit) {
		super(accNo, accNm, accBal);
		this.creditLimit = creditLimit;
	}

	protected final float creditLimit;
	
	public void withdraw (float creditLimit)
	{
		System.out.println("credit limit is :"+creditLimit);
	}

	@Override
	public String toString() {
		return "CurrentAcc [creditLimit=" + creditLimit + ", accNo=" + accNo + ", accNm=" + accNm + ", accBal=" + accBal
				+ ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ "]";
	}

	public float creditlimit() {
		// TODO Auto-generated method stub
		return creditLimit;
	}

	
}
