package com.ajay.client;



import com.ajay.application.MMBankFactory;
import com.ajay.application.MMCurrentAcc;
import com.ajay.application.MMSavingAcc;
import com.ajay.framework.BankFactory;
import com.ajay.framework.CurrentAcc;
import com.ajay.framework.SavingAcc;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BankFactory bf = new MMBankFactory();
		
		
		SavingAcc sa = new MMSavingAcc(12345,"Ajay",20000,true);
		sa.withdraw(sa.accBal);
		sa.toString();
		
		CurrentAcc ca = new MMCurrentAcc(12345,"Ajay",20000,2000);
		ca.withdraw(ca.creditlimit());
		ca.toString();
	}

}
