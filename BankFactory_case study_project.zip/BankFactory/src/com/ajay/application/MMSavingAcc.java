package com.ajay.application;

import com.ajay.framework.SavingAcc;

public class MMSavingAcc extends SavingAcc{

	public MMSavingAcc(int accNo, String accNm, float accBal, boolean isSalary) {
		super(accNo, accNm, accBal, isSalary);
		// TODO Auto-generated constructor stub
	}
	protected static final float MINBAL = 500;
	
	public void withdraw (float accBal)
	{
		System.out.println("Dear user your accBal is:"+accBal);
	}

	@Override
	public String toString() {
		return "MMSavingAcc [isSalary=" + isSalary + ", accNo=" + accNo + ", accNm=" + accNm + ", accBal=" + accBal
				+ ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ "]";
	}

}
