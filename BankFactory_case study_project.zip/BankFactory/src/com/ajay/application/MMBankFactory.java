package com.ajay.application;

import com.ajay.framework.BankFactory;
import com.ajay.framework.CurrentAcc;

public  class MMBankFactory extends BankFactory{
	
	public MMSavingAcc getNewSavingAccount(int accNo,String accNm,float accBal,boolean isSalary) {
	MMSavingAcc mmsaving = new MMSavingAcc(accNo,accNm,accBal,isSalary);
	return mmsaving;
	}
	public MMCurrentAcc getCurrentAccount(int accNo,String accNm,float accBal,float creditLimit) {
		MMCurrentAcc mmcurrent = new MMCurrentAcc(accNo,accNm,accBal,creditLimit);
		return mmcurrent;
	}
	@Override
	public CurrentAcc getNewCurrentAccount(int accNo, String accNm, float accBal, float creditLimit) {
		// TODO Auto-generated method stub
		return null;
	}
}